That's part of .ipynb that converts human motion video to .bvh. More info here: https://github.com/Dene33/video_to_bvh
